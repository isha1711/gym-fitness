import React from "react";
import HeroSection from "./components/HeroSection";
import Features from "./components/Features";
import Plans from "./components/Plans";
import Footer from "./components/Footer";
import "./App.css";
import FeedbackForm from "./components/Feedback";
import OnlineStore from "./components/Store";




function App() {
  return (
    <div className="App">
      <HeroSection />
      <Features />
      <Plans />
     
      <OnlineStore/>
      <FeedbackForm/>
      <Footer />
    
    </div>
  );
}

export default App;
