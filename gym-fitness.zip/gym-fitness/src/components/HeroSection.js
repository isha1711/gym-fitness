// import React from "react";
// import { motion } from "framer-motion";
// import "./HeroSection.css";

// function HeroSection() {
//   return (
//     <div className="hero">
//       {/* Navigation Bar */}
//       <div className="navbar">
//         <div className="logo">Gym AI</div>
//         <div className="nav-links">
//           <a href="#features">Features</a>
//           <a href="#membership">Membership</a>
//           <a href="#services">Services</a>
      
//         </div>
//         <button className="login">Login</button>
//         <button className="signup">Sign Up</button>
//       </div>

//       {/* Hero Content */}
//       <motion.h1
//         initial={{ opacity: 0, y: -50 }}
//         animate={{ opacity: 1, y: 0 }}
//         transition={{ duration: 0.8 }}
//       >
//         Transform Your Fitness Journey
//       </motion.h1>
//       <motion.p
//         initial={{ opacity: 0 }}
//         animate={{ opacity: 1 }}
//         transition={{ delay: 0.4, duration: 0.8 }}
//       >
//         Join the best gym in town for a healthier you.
//       </motion.p>
//       <motion.button
//         initial={{ scale: 0 }}
//         animate={{ scale: 1 }}
//         transition={{ delay: 0.8, duration: 0.5 }}
//         className="hero-btn"
//       >
//         Join Now
//       </motion.button>
//     </div>
//   );
// }

// export default HeroSection;

import React from 'react';
import { motion } from 'framer-motion';
import './HeroSection.css';

function HeroSection() {
  return (
    <div className="hero">
        {/* Navigation Bar */}
       <div className="navbar">
         <div className="logo">Gym AI</div>
         <div className="nav-links">
           <a href="#features">Features</a>
           <a href="#membership">Membership</a>
           <a href="#services">Services</a>
      
         </div>
         <button className="login">Login</button>
         <button className="signup">Sign Up</button>
       </div>
      <div className="hero-content">
      <motion.h1
         initial={{ opacity: 0, y: -50 }}
         animate={{ opacity: 1, y: 0 }}
         transition={{ duration: 0.8 }}
       >
         Transform Your Fitness Journey
       </motion.h1>
       <motion.p
         initial={{ opacity: 0 }}
         animate={{ opacity: 1 }}
         transition={{ delay: 0.4, duration: 0.8 }}
       >
         Join the best gym in town for a healthier you.
       </motion.p>
       <motion.button
         initial={{ scale: 0 }}
         animate={{ scale: 1 }}
         transition={{ delay: 0.8, duration: 0.5 }}
         className="hero-btn"
       >
         Join Now
       </motion.button>
      </div>
    </div>
  );
}

export default HeroSection;
