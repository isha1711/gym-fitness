// import React from "react";
import { motion } from "framer-motion";
import "./Features.css";

const features = [
  { id: 1, icon: "🏋️", title: "Professional Trainers", description: "Get trained by certified professionals to achieve your goals." },
  { id: 2, icon: "💪", title: "Custom Workouts", description: "Tailored workout plans designed just for you." },
  { id: 3, icon: "🏅", title: "State-of-the-art Equipment", description: "Top-quality gym equipment for effective training." },
  { id: 4, icon: "🕒", title: "Flexible Timings", description: "Choose a schedule that fits your lifestyle." },
  { id: 5, icon: "🥗", title: "Nutrition Guidance", description: "Expert advice on diet and nutrition to complement your workouts." },
  { id: 6, icon: "📊", title: "Progress Tracking", description: "Track your fitness progress with advanced analytics and reports." },
  { id: 7, icon: "🧘‍♂️", title: "Mind & Body Wellness", description: "Experience holistic fitness with yoga, meditation, and stress management." },
];

function Features() {
  return (
    <div id="features" className="features">
      <h2>Why Choose Us</h2>
      <div className="features-container">
        {features.map((feature, index) => (
          <motion.div
            className="feature-card"
            key={feature.id}
            whileHover={{ scale: 1.05 }}
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: index * 0.2 }}
          >
            <div className="icon">{feature.icon}</div>
            <h3>{feature.title}</h3>
            <p>{feature.description}</p>
          </motion.div>
        ))}
      </div>
    </div>
  );
}

export default Features;
