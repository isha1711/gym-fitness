import React from "react";
import { motion } from "framer-motion";
import './Store.css';

function OnlineStore() {
  const products = [
    { id: 1, name: "Gym T-shirt", price: "200Rs", image: "", className: "gymtees" },
    { id: 2, name: "Dumbbell Set", price: "550Rs", image: "", className: "dumbbell" },
    { id: 3, name: "Yoga Mat", price: "1500Rs", image: "", className: "yogamat" },
    { id: 4, name: "Protein Powder", price: "600Rs", image: "", className: "protein" },
  ];

  return (
    <div className="store-container">
      <h2>Our Gym Store</h2>
      <motion.div
        className="products"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1 }}
      >
        {products.map(product => (
          <motion.div
            key={product.id}
            className={`product-card ${product.className}`}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1, delay: product.id * 0.2 }}
          >
            {product.image && <img src={product.image} alt={product.name} className="product-image" />}
            <div className="product-info">
              <h3>{product.name}</h3>
              <p>{product.price}</p>
              <button className="buy-btn">Buy Now</button>
            </div>
          </motion.div>
        ))}
      </motion.div>
    </div>
  );
}

export default OnlineStore;
