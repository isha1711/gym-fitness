import React from "react";
import { motion } from "framer-motion";
import "./Plans.css";

const plans = [
  {
    id: 1,
    name: "Basic Plan",
    price: "$20/month",
    features: ["Access to Gym", "Free Locker"],
    color: "#5A9BCF", // Soft Blue
  },
  {
    id: 2,
    name: "Premium Plan",
    price: "$50/month",
    features: ["Access to Gym", "Free Locker", "Personal Trainer", "Custom Workouts"],
    color: "#F0A1C1", // Dusty Pink
  },
  {
    id: 3,
    name: "Elite Plan",
    price: "$80/month",
    features: ["Access to Gym", "Free Locker", "Personal Trainer", "Custom Workouts", "Nutrition Guidance"],
    color: "#2D6A4F", // Emerald Green
  },
];
function MembershipPlans() {
  return (
    <div id="membership" className="membership">
      <h2>Choose Your Plan</h2>
      <div className="membership-container">
        {plans.map((plan, index) => (
          <motion.div
            key={plan.id}
            className="membership-card"
            style={{ backgroundColor: plan.color }}
            whileHover={{ scale: 1.05 }}
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: index * 0.2 }}
          >
            <h3>{plan.name}</h3>
            <p className="price">{plan.price}</p>
            <ul>
              {plan.features.map((feature, i) => (
                <li key={i}>{feature}</li>
              ))}
            </ul>
            <button className="plan-btn">Get Started</button>
          </motion.div>
        ))}
      </div>
    </div>
  );
}

export default MembershipPlans;
