import React, { useState } from 'react';
import { motion } from 'framer-motion';
import './FeedbackForm.css';

function FeedbackForm() {
  const [name, setName] = useState('');
  const [feedback, setFeedback] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState('');

  
  const [feedbackList, setFeedbackList] = useState([
    { name: 'Isha Khatri', message: 'Great gym! The equipment is top-notch.' },
    { name: 'Vraj Shah', message: 'I love the classes and trainers!' },
    { name: 'Parv Khatri', message: 'Amazing atmosphere. Keep up the good work!' }
  ]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!name || !feedback) {
      setError('Both fields are required');
      return;
    }

   
    setFeedbackList([...feedbackList, { name, message: feedback }]);
    setName('');
    setFeedback('');
    setSubmitted(true);
    setError('');
  };

  return (
    <div className="feedback-form-container">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
        className="feedback-form"
      >
        <h2>User Feedback</h2>

        {submitted ? (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5 }}
            className="thank-you-message"
          >
            <h3>Thank you for your feedback, {name}!</h3>
            <p>We appreciate your input and will use it to improve our services.</p>
          </motion.div>
        ) : (
          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label htmlFor="name">Name</label>
              <input
                type="text"
                id="name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Enter your name"
                className="form-control"
              />
            </div>

            <div className="form-group">
              <label htmlFor="feedback">Feedback</label>
              <textarea
                id="feedback"
                value={feedback}
                onChange={(e) => setFeedback(e.target.value)}
                placeholder="Enter your feedback"
                className="form-control"
              />
            </div>

            {error && <p className="error-message">{error}</p>}

            <button type="submit" className="submit-btn">Submit Feedback</button>
          </form>
        )}

        <div className="existing-feedback">
          <h3>Previous Feedback</h3>
          <ul>
            {feedbackList.map((item, index) => (
              <li key={index} className="feedback-item">
                <strong>{item.name}</strong>: {item.message}
              </li>
            ))}
          </ul>
        </div>
      </motion.div>
    </div>
  );
}

export default FeedbackForm;
